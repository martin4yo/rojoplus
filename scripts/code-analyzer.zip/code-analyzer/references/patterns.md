# Common React/JS Patterns — Reference Guide

Use this reference when analyzing code to identify specific anti-patterns and suggest targeted solutions.

## Duplication Patterns to Detect

### 1. Duplicated API Call Logic
**Symptom:** Multiple components with similar fetch/axios calls, each handling loading/error states independently.
**Solution:** Extract to a custom hook like `useApi()` or `useFetch()` or a service module.

### 2. Duplicated Form Handling
**Symptom:** Multiple forms repeating validation, onChange handlers, submit logic.
**Solution:** Extract to `useForm()` custom hook or adopt a library pattern (Formik/React Hook Form style).

### 3. Duplicated Modal/Dialog Patterns
**Symptom:** Multiple components implementing open/close state with similar overlay JSX.
**Solution:** Create a reusable `<Modal>` component with render props or children pattern.

### 4. Duplicated Table/List Rendering
**Symptom:** Multiple components mapping arrays to similar JSX structures (cards, rows, items).
**Solution:** Create generic `<DataList>` or `<DataTable>` components with column/render config.

### 5. Duplicated Auth Checks
**Symptom:** Multiple components checking user roles/permissions with similar conditional logic.
**Solution:** Create `<ProtectedRoute>`, `useAuth()` hook, or HOC `withAuth()`.

### 6. Copy-Paste Components
**Symptom:** Components that are 80%+ identical with minor prop/text differences.
**Solution:** Merge into single component with props for the varying parts.

## Optimization Patterns

### Performance
- `useMemo` for expensive calculations in render
- `useCallback` for functions passed as props to child components
- `React.memo` for pure display components receiving same props
- Code splitting with `React.lazy` for route-based components
- Virtualization for long lists (react-window, react-virtualized)

### State Management
- Lift state up only as far as needed
- Colocate state near where it's used
- Use Context for truly global state (theme, auth, locale)
- Avoid putting everything in a single global store

### Component Structure
- Components >200 lines should probably be split
- Separate logic (hooks) from presentation (JSX)
- Container/Presenter pattern for complex components
- Barrel exports (index.js) for feature directories

## Naming Convention Checks

### React Standard
- Components: PascalCase (`UserCard`, `NavBar`)
- Hooks: camelCase with "use" prefix (`useAuth`, `useFetch`)
- Constants: UPPER_SNAKE_CASE (`API_BASE_URL`, `MAX_RETRIES`)
- Event handlers: "handle" prefix (`handleClick`, `handleSubmit`)
- Boolean props: "is/has/should" prefix (`isLoading`, `hasError`)
- Files: Match default export name (`UserCard.jsx` exports `UserCard`)

## Refactoring Priority Matrix

| Impact | Effort Low | Effort Medium | Effort High |
|--------|-----------|---------------|-------------|
| High   | DO FIRST  | DO SECOND     | PLAN        |
| Medium | DO SECOND | EVALUATE      | BACKLOG     |
| Low    | OPTIONAL  | BACKLOG       | SKIP        |
