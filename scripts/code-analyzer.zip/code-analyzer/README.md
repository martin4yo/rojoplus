# Code Analyzer Skill — Guía de Instalación

## Contenido del paquete

```
code-analyzer/
├── SKILL.md              → Instrucciones principales del skill
├── scripts/
│   └── analyze.py        → Script Python de análisis automático
└── references/
    └── patterns.md       → Guía de anti-patterns React/JS
```

## Instalación

### Opción A: Claude Code (VSCode / Terminal)

1. Copiá la carpeta `code-analyzer/` a tu proyecto:

```bash
# Global (disponible en todos los proyectos)
cp -r code-analyzer ~/.claude/skills/

# O por proyecto específico
mkdir -p tu-proyecto/.claude/skills/
cp -r code-analyzer tu-proyecto/.claude/skills/
```

2. Abrí Claude Code y usalo:
```
> analizá los componentes de src/ buscando duplicaciones
> /code-analyzer
```

### Opción B: claude.ai (Web)

1. Andá a **Settings > Features**
2. En la sección de Skills, hacé clic en **Upload Skill**
3. Seleccioná el archivo `code-analyzer.zip`
4. Listo — Claude lo usa automáticamente cuando le pedís análisis de código

## Qué detecta

- **Duplicación exacta** — Bloques de código idénticos entre archivos
- **Duplicación estructural** — Mismo patrón con diferentes nombres de variables
- **Archivos similares** — Componentes que deberían unificarse
- **Imports repetidos** — Candidatos para barrel exports
- **Hooks duplicados** — useEffect/useState con patrones similares
- **Archivos grandes** — Componentes que deberían dividirse (>200 líneas)

## Ejemplos de uso

```
"Analizá mi proyecto React y buscá código duplicado"
"¿Qué componentes puedo unificar en src/components?"
"Revisá este proyecto y sugerí refactors"
"Buscá oportunidades de extraer custom hooks"
"Generame un reporte de calidad de código"
```

## Requisitos

- Python 3.8+ (para el script de análisis)
- No requiere dependencias externas (usa solo stdlib de Python)
