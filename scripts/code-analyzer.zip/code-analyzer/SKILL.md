---
name: code-analyzer
description: Analyze JavaScript/React projects to detect code duplication, optimization opportunities, and component reuse potential. Use this skill whenever the user asks to analyze code, review a project for duplications, find repeated patterns, optimize components, identify refactoring opportunities, unify processes, detect dead code, or improve code quality. Trigger when the user mentions "analyze", "review", "duplications", "refactor", "optimize", "repeated code", "extract component", "code quality", "code review", "clean up", "consolidate", "unify", or uploads JS/JSX/TS/TSX files asking for improvements. Also trigger when the user provides a GitHub repo URL for code analysis, or when they say things like "check my code", "what can I improve", "find problems in my project".
---

# Code Analyzer — JavaScript/React Project Analysis

## Overview

Scan JavaScript/React projects to identify duplications, optimization opportunities, and component extraction candidates. Generate actionable reports with specific refactoring suggestions and ready-to-use code.

## Input Handling

### Step 1: Identify the source

Determine how the user is providing their code:

**A) Uploaded files (ZIP or individual)**
- Check `/mnt/user-data/uploads/` for uploaded files
- If ZIP: extract to `/home/claude/analysis-workspace/`
- If individual files: copy to `/home/claude/analysis-workspace/`

**B) GitHub repository**
- Clone to `/home/claude/analysis-workspace/`
- `git clone <repo-url> /home/claude/analysis-workspace/project`

**C) Pasted code or files already in conversation**
- Save to `/home/claude/analysis-workspace/` maintaining structure

### Step 2: Scan the project structure

```bash
find /home/claude/analysis-workspace -type f \( -name "*.js" -o -name "*.jsx" -o -name "*.ts" -o -name "*.tsx" \) | head -200
```

Report the project structure to the user before analyzing. Count total files, lines of code, and identify the framework (React, Next.js, Vue, vanilla JS).

## Analysis Process

### Step 3: Run the automated analysis script

Execute the bundled analysis script:

```bash
python3 {baseDir}/scripts/analyze.py /home/claude/analysis-workspace
```

This script produces a JSON report with:
- Duplicated code blocks (by text similarity)
- Files with similar structure
- Repeated import patterns
- Functions with similar signatures

### Step 4: Deep analysis by Claude

After the script runs, perform **manual deep analysis** on the results. The script catches syntactic duplication; Claude must catch **semantic duplication** — code that does the same thing differently.

For each file, evaluate:

#### 4a. Code Duplication
- **Exact duplicates**: Identical or near-identical blocks (script catches these)
- **Semantic duplicates**: Different code that achieves the same result
- **Pattern duplicates**: Same structure with different variable names
- **Cross-file duplication**: Same logic in multiple components

#### 4b. Component Extraction Opportunities
- Repeated JSX patterns → Extract to shared component
- Repeated hooks logic → Extract to custom hook
- Repeated utility functions → Extract to utils module
- Repeated API call patterns → Extract to service layer
- Repeated form handling → Extract to form hook or HOC
- Repeated styling patterns → Extract to shared styles/theme

#### 4c. Optimization Opportunities
- Unnecessary re-renders (missing memo, useMemo, useCallback)
- Large components that should be split (>200 lines)
- Inline functions in JSX that recreate every render
- Missing error boundaries
- Prop drilling that could use Context
- Unused imports and dead code
- Inefficient state management patterns
- Missing loading/error states

#### 4d. Code Quality Issues
- Inconsistent naming conventions
- Mixed patterns (some files use hooks, others classes)
- Missing PropTypes or TypeScript types
- Hardcoded values that should be constants
- Console.logs left in production code
- TODO/FIXME comments that need attention

## Output Format

### Step 5: Choose output based on user preference

Ask the user how they want the report OR infer from context:

**Option A: Chat report (default for quick reviews)**
Present findings organized by severity:
1. 🔴 **Critical** — Direct duplications, copy-paste code
2. 🟡 **Important** — Component extraction opportunities, optimization wins
3. 🟢 **Suggestions** — Code quality improvements, best practices

For each finding include:
- File(s) affected with line numbers
- What the problem is
- Concrete solution with code example
- Estimated impact (high/medium/low)

**Option B: Markdown/Word document (for documentation)**
Generate a professional report using the docx skill if available, otherwise Markdown. Include:
- Executive summary with metrics
- Detailed findings by category
- Recommended refactoring plan with priority order
- Before/after code examples

**Option C: Interactive dashboard artifact (for visual overview)**
Create a React artifact showing:
- Project health score (0-100)
- Treemap of files by duplication level
- List of findings filterable by severity
- Code diff previews for each suggestion

## Refactoring Suggestions Format

When suggesting refactors, ALWAYS provide:

```
📁 FINDING: [Short description]
📍 Location: src/components/UserCard.jsx (lines 45-78)
              src/components/ProfileCard.jsx (lines 23-56)

🔍 PROBLEM:
Both components render a user avatar with name and role badge.
~34 lines of duplicated JSX and styling logic.

✅ SOLUTION: Extract to <UserBadge /> component

// NEW FILE: src/components/shared/UserBadge.jsx
export function UserBadge({ name, role, avatarUrl, size = 'md' }) {
  return (
    <div className={`user-badge user-badge--${size}`}>
      <img src={avatarUrl} alt={name} />
      <span className="user-badge__name">{name}</span>
      <RoleBadge role={role} />
    </div>
  );
}

// UPDATED: src/components/UserCard.jsx (line 45)
- <div className="avatar-container">... 34 lines ...</div>
+ <UserBadge name={user.name} role={user.role} avatarUrl={user.avatar} />

💡 IMPACT: Eliminates 34 duplicated lines, single source of truth for user display
```

## Priority Scoring

Score each finding for prioritization:

| Factor | Weight | Criteria |
|--------|--------|----------|
| Duplication count | 30% | How many times the pattern repeats |
| Lines affected | 25% | Total lines that would be reduced |
| Bug risk | 25% | Likelihood of inconsistency causing bugs |
| Effort to fix | 20% | Low effort = higher priority |

## Important Guidelines

- Never suggest refactoring that changes functionality
- Always preserve existing behavior
- Consider backwards compatibility
- Note if a refactor requires updating tests
- If using TypeScript, maintain type safety in suggestions
- Account for the user's framework (Next.js has different patterns than CRA)
- Be specific with file paths and line numbers
- Provide complete, copy-pasteable code solutions
- Group related changes into logical refactoring steps
- Suggest an order of execution for the refactoring plan
