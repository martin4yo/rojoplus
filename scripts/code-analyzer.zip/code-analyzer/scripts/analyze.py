#!/usr/bin/env python3
"""
Code Analyzer Script — JavaScript/React Project Analysis
Scans a project directory for code duplication, similar files, and repeated patterns.
Outputs a structured JSON report for Claude to interpret and enhance.
"""

import os
import sys
import json
import re
import hashlib
from collections import defaultdict, Counter
from difflib import SequenceMatcher
from pathlib import Path

# Configuration
EXTENSIONS = {'.js', '.jsx', '.ts', '.tsx', '.mjs'}
IGNORE_DIRS = {'node_modules', '.next', 'dist', 'build', '.git', 'coverage', '__tests__', '__mocks__', '.cache', '.turbo'}
MIN_BLOCK_LINES = 4          # Minimum lines for a block to be considered
SIMILARITY_THRESHOLD = 0.75  # 75% similarity to flag as duplicate
MIN_FUNCTION_LINES = 3       # Minimum function body lines to analyze


def should_ignore(path):
    """Check if path should be ignored."""
    parts = Path(path).parts
    return any(d in parts for d in IGNORE_DIRS)


def collect_files(root_dir):
    """Collect all relevant source files."""
    files = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
        for f in filenames:
            ext = os.path.splitext(f)[1]
            if ext in EXTENSIONS:
                full_path = os.path.join(dirpath, f)
                if not should_ignore(full_path):
                    files.append(full_path)
    return sorted(files)


def read_file_safe(filepath):
    """Read file with fallback encoding."""
    for enc in ('utf-8', 'latin-1'):
        try:
            with open(filepath, 'r', encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, IOError):
            continue
    return ""


def normalize_code(code):
    """Normalize code for comparison (strip comments, whitespace)."""
    # Remove single-line comments
    code = re.sub(r'//.*$', '', code, flags=re.MULTILINE)
    # Remove multi-line comments
    code = re.sub(r'/\*[\s\S]*?\*/', '', code)
    # Normalize whitespace
    code = re.sub(r'\s+', ' ', code).strip()
    return code


def structural_normalize(code):
    """Aggressively normalize code for structural comparison.
    Replaces identifiers and strings with placeholders to detect
    same-structure-different-names patterns."""
    code = normalize_code(code)
    # Replace string literals
    code = re.sub(r'"[^"]*"', '"_STR_"', code)
    code = re.sub(r"'[^']*'", "'_STR_'", code)
    code = re.sub(r'`[^`]*`', '`_STR_`', code)
    # Replace specific identifiers but keep structure keywords
    # Replace camelCase/PascalCase identifiers (but not keywords)
    js_keywords = {'import','export','from','const','let','var','function','return',
                   'if','else','for','while','do','switch','case','break','continue',
                   'try','catch','finally','throw','new','delete','typeof','instanceof',
                   'class','extends','super','this','null','undefined','true','false',
                   'async','await','yield','default','void','in','of','with',
                   'useState','useEffect','useCallback','useMemo','useRef','useContext'}
    
    def replace_identifier(match):
        word = match.group(0)
        if word in js_keywords:
            return word
        return '_ID_'
    
    code = re.sub(r'\b[a-zA-Z_$][a-zA-Z0-9_$]*\b', replace_identifier, code)
    return code


def extract_blocks(lines, min_lines=MIN_BLOCK_LINES):
    """Extract meaningful code blocks (functions, components, etc.)."""
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # Detect function/component/hook declarations
        if re.match(r'^(export\s+)?(default\s+)?(async\s+)?function\s+\w+', line) or \
           re.match(r'^(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s+)?\(', line) or \
           re.match(r'^(export\s+)?(const|let|var)\s+\w+\s*=\s*\(?\s*\w*\s*\)?\s*=>', line) or \
           re.match(r'^(export\s+)?class\s+\w+', line):
            
            # Find the block end by tracking braces
            brace_count = 0
            block_start = i
            started = False
            for j in range(i, len(lines)):
                brace_count += lines[j].count('{') - lines[j].count('}')
                if '{' in lines[j]:
                    started = True
                if started and brace_count <= 0:
                    block_lines = lines[block_start:j+1]
                    if len(block_lines) >= min_lines:
                        blocks.append({
                            'start_line': block_start + 1,
                            'end_line': j + 1,
                            'lines': block_lines,
                            'header': line.strip(),
                            'content': '\n'.join(block_lines)
                        })
                    i = j + 1
                    break
            else:
                i += 1
        else:
            i += 1
    return blocks


def extract_imports(content):
    """Extract import statements."""
    imports = []
    for match in re.finditer(r"import\s+(?:{[^}]+}|\w+(?:\s*,\s*{[^}]+})?)\s+from\s+['\"]([^'\"]+)['\"]", content):
        imports.append(match.group(0))
    return imports


def extract_jsx_patterns(content):
    """Extract JSX patterns (repeated component usage, structure)."""
    patterns = []
    # Find JSX return blocks
    for match in re.finditer(r'return\s*\(\s*([\s\S]*?)\);', content):
        jsx = match.group(1).strip()
        if len(jsx) > 50:  # Non-trivial JSX
            # Normalize variable names to find structural patterns
            normalized = re.sub(r'\{[^}]+\}', '{...}', jsx)
            normalized = re.sub(r'"[^"]*"', '"..."', normalized)
            normalized = re.sub(r"'[^']*'", "'...'", normalized)
            patterns.append({
                'original': jsx[:500],
                'normalized': normalized[:500],
                'length': len(jsx)
            })
    return patterns


def extract_hooks_usage(content):
    """Extract React hooks usage patterns."""
    hooks = []
    # useState patterns
    for match in re.finditer(r'const\s+\[(\w+),\s*set\w+\]\s*=\s*useState\(([^)]*)\)', content):
        hooks.append({'type': 'useState', 'name': match.group(1), 'initial': match.group(2)})
    # useEffect patterns
    for match in re.finditer(r'useEffect\(\s*\(\)\s*=>\s*\{([\s\S]*?)\},\s*\[([^\]]*)\]\s*\)', content):
        hooks.append({'type': 'useEffect', 'body_preview': match.group(1)[:200].strip(), 'deps': match.group(2)})
    return hooks


def find_duplicate_blocks(all_blocks):
    """Find duplicate code blocks across files using similarity matching."""
    duplicates = []
    block_list = []
    
    for filepath, blocks in all_blocks.items():
        for block in blocks:
            normalized = normalize_code(block['content'])
            structural = structural_normalize(block['content'])
            if len(normalized) > 30:  # Skip trivially small blocks
                block_list.append({
                    'file': filepath,
                    'block': block,
                    'normalized': normalized,
                    'structural': structural,
                    'hash': hashlib.md5(normalized.encode()).hexdigest(),
                    'struct_hash': hashlib.md5(structural.encode()).hexdigest()
                })
    
    # First pass: exact duplicates by hash
    hash_groups = defaultdict(list)
    for item in block_list:
        hash_groups[item['hash']].append(item)
    
    for h, items in hash_groups.items():
        if len(items) > 1:
            files_involved = list(set(i['file'] for i in items))
            if len(files_involved) > 1 or len(items) > 1:
                duplicates.append({
                    'type': 'exact',
                    'similarity': 1.0,
                    'locations': [{'file': i['file'], 'lines': f"{i['block']['start_line']}-{i['block']['end_line']}", 'header': i['block']['header']} for i in items],
                    'line_count': len(items[0]['block']['lines']),
                    'preview': items[0]['block']['content'][:300]
                })
    
    # Structural duplicates (same structure, different names)
    struct_groups = defaultdict(list)
    for item in block_list:
        struct_groups[item['struct_hash']].append(item)
    
    for sh, items in struct_groups.items():
        if len(items) > 1:
            # Skip if already found as exact duplicate
            if any(i['hash'] in {it['hash'] for group in hash_groups.values() if len(group) > 1 for it in group} for i in items):
                continue
            files_involved = list(set(i['file'] for i in items))
            if len(files_involved) > 1 or len(items) > 1:
                duplicates.append({
                    'type': 'structural',
                    'similarity': 0.95,
                    'locations': [{'file': i['file'], 'lines': f"{i['block']['start_line']}-{i['block']['end_line']}", 'header': i['block']['header']} for i in items],
                    'line_count': len(items[0]['block']['lines']),
                    'preview': items[0]['block']['content'][:300]
                })
    
    # Second pass: similar blocks by structural comparison
    exact_hashes = {h for h, items in hash_groups.items() if len(items) > 1}
    struct_exact = {sh for sh, items in struct_groups.items() if len(items) > 1}
    remaining = [b for b in block_list if b['hash'] not in exact_hashes and b['struct_hash'] not in struct_exact]
    
    compared = set()
    for i, a in enumerate(remaining):
        for j, b in enumerate(remaining):
            if i >= j:
                continue
            pair_key = (a['hash'], b['hash'])
            if pair_key in compared:
                continue
            compared.add(pair_key)
            
            ratio = SequenceMatcher(None, a['structural'], b['structural']).ratio()
            if ratio >= SIMILARITY_THRESHOLD:
                duplicates.append({
                    'type': 'similar',
                    'similarity': round(ratio, 3),
                    'locations': [
                        {'file': a['file'], 'lines': f"{a['block']['start_line']}-{a['block']['end_line']}", 'header': a['block']['header']},
                        {'file': b['file'], 'lines': f"{b['block']['start_line']}-{b['block']['end_line']}", 'header': b['block']['header']}
                    ],
                    'line_count': max(len(a['block']['lines']), len(b['block']['lines'])),
                    'preview_a': a['block']['content'][:200],
                    'preview_b': b['block']['content'][:200]
                })
    
    return sorted(duplicates, key=lambda d: (-d['similarity'], -d['line_count']))


def find_similar_files(files_data):
    """Find files with similar overall structure."""
    similar_pairs = []
    file_list = list(files_data.items())
    
    for i in range(len(file_list)):
        for j in range(i + 1, len(file_list)):
            path_a, data_a = file_list[i]
            path_b, data_b = file_list[j]
            
            norm_a = normalize_code(data_a['content'])
            norm_b = normalize_code(data_b['content'])
            
            if len(norm_a) < 50 or len(norm_b) < 50:
                continue
            
            # Use quick length check to skip obviously different files
            len_ratio = min(len(norm_a), len(norm_b)) / max(len(norm_a), len(norm_b))
            if len_ratio < 0.5:
                continue
            
            ratio = SequenceMatcher(None, norm_a, norm_b).ratio()
            
            # Also check structural similarity
            struct_a = structural_normalize(data_a['content'])
            struct_b = structural_normalize(data_b['content'])
            struct_ratio = SequenceMatcher(None, struct_a, struct_b).ratio()
            
            best_ratio = max(ratio, struct_ratio)
            
            if best_ratio >= 0.6:
                similar_pairs.append({
                    'file_a': path_a,
                    'file_b': path_b,
                    'similarity': round(best_ratio, 3),
                    'structural_similarity': round(struct_ratio, 3),
                    'lines_a': data_a['line_count'],
                    'lines_b': data_b['line_count']
                })
    
    return sorted(similar_pairs, key=lambda x: -x['similarity'])


def find_repeated_imports(files_data):
    """Find imports that appear across many files (candidates for barrel exports)."""
    import_counter = Counter()
    import_files = defaultdict(list)
    
    for filepath, data in files_data.items():
        for imp in data['imports']:
            # Normalize import
            norm = re.sub(r'\s+', ' ', imp).strip()
            import_counter[norm] += 1
            import_files[norm].append(filepath)
    
    repeated = []
    for imp, count in import_counter.most_common():
        if count >= 3:  # Used in 3+ files
            repeated.append({
                'import': imp,
                'count': count,
                'files': import_files[imp][:10]  # Cap at 10 files for readability
            })
    
    return repeated


def find_large_files(files_data, threshold=200):
    """Find files that exceed the line threshold."""
    large = []
    for filepath, data in files_data.items():
        if data['line_count'] > threshold:
            large.append({
                'file': filepath,
                'lines': data['line_count'],
                'block_count': len(data['blocks']),
                'suggestion': 'Consider splitting into smaller modules'
            })
    return sorted(large, key=lambda x: -x['lines'])


def find_repeated_hooks_patterns(files_data):
    """Find similar useState/useEffect patterns across files."""
    effect_patterns = defaultdict(list)
    state_patterns = defaultdict(list)
    
    for filepath, data in files_data.items():
        for hook in data['hooks']:
            if hook['type'] == 'useEffect':
                # Group by dependency pattern
                deps_key = hook.get('deps', '').strip()
                effect_patterns[deps_key].append({
                    'file': filepath,
                    'preview': hook.get('body_preview', '')[:100]
                })
            elif hook['type'] == 'useState':
                state_patterns[hook.get('initial', '')].append({
                    'file': filepath,
                    'name': hook.get('name', '')
                })
    
    repeated_effects = []
    for deps, locations in effect_patterns.items():
        if len(locations) >= 2:
            repeated_effects.append({
                'deps': deps or '[]',
                'count': len(locations),
                'locations': locations[:8],
                'suggestion': 'Consider extracting to a custom hook'
            })
    
    return sorted(repeated_effects, key=lambda x: -x['count'])


def analyze_project(root_dir):
    """Main analysis function."""
    root_dir = os.path.abspath(root_dir)
    files = collect_files(root_dir)
    
    if not files:
        return {
            'error': f'No JavaScript/React files found in {root_dir}',
            'scanned_extensions': list(EXTENSIONS)
        }
    
    # Collect data from all files
    files_data = {}
    all_blocks = {}
    total_lines = 0
    
    for filepath in files:
        content = read_file_safe(filepath)
        lines = content.split('\n')
        rel_path = os.path.relpath(filepath, root_dir)
        
        blocks = extract_blocks(lines)
        imports = extract_imports(content)
        jsx_patterns = extract_jsx_patterns(content)
        hooks = extract_hooks_usage(content)
        
        files_data[rel_path] = {
            'content': content,
            'line_count': len(lines),
            'blocks': blocks,
            'imports': imports,
            'jsx_patterns': jsx_patterns,
            'hooks': hooks
        }
        all_blocks[rel_path] = blocks
        total_lines += len(lines)
    
    # Run all analyses
    duplicates = find_duplicate_blocks(all_blocks)
    similar_files = find_similar_files(files_data)
    repeated_imports = find_repeated_imports(files_data)
    large_files = find_large_files(files_data)
    repeated_hooks = find_repeated_hooks_patterns(files_data)
    
    # Calculate metrics
    total_duplicate_lines = sum(d['line_count'] * len(d['locations']) for d in duplicates if d['type'] == 'exact')
    duplication_ratio = round(total_duplicate_lines / max(total_lines, 1) * 100, 1)
    
    # Health score (0-100)
    health = 100
    health -= min(30, len(duplicates) * 3)                  # Duplicates penalty
    health -= min(15, len(similar_files) * 5)                # Similar files penalty
    health -= min(15, len(large_files) * 5)                  # Large files penalty
    health -= min(10, max(0, duplication_ratio - 5) * 2)     # High duplication penalty
    health -= min(10, len(repeated_hooks) * 2)               # Repeated patterns penalty
    health = max(0, health)
    
    report = {
        'summary': {
            'root_dir': root_dir,
            'total_files': len(files),
            'total_lines': total_lines,
            'health_score': health,
            'duplication_ratio_pct': duplication_ratio,
            'files_analyzed': len(files_data)
        },
        'duplicates': duplicates[:30],           # Top 30 duplications
        'similar_files': similar_files[:15],     # Top 15 similar file pairs
        'repeated_imports': repeated_imports[:20],
        'large_files': large_files[:10],
        'repeated_hooks': repeated_hooks[:15],
        'file_inventory': {
            path: {
                'lines': data['line_count'],
                'blocks': len(data['blocks']),
                'imports': len(data['imports']),
                'hooks': len(data['hooks'])
            }
            for path, data in files_data.items()
        }
    }
    
    return report


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze.py <project-directory>", file=sys.stderr)
        sys.exit(1)
    
    root_dir = sys.argv[1]
    if not os.path.isdir(root_dir):
        print(json.dumps({'error': f'Directory not found: {root_dir}'}))
        sys.exit(1)
    
    report = analyze_project(root_dir)
    
    # Output JSON report
    print(json.dumps(report, indent=2, default=str))


if __name__ == '__main__':
    main()
